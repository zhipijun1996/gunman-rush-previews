from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
OUT=Path('/workspace/pcg-research/delivery')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
 context=b.new_context(viewport={'width':1280,'height':720})
 page=context.new_page();events=[];errors=[];records=[]
 page.on('console',lambda m:events.append({'type':m.type,'text':m.text}));page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8028',wait_until='networkidle',timeout=90000)
 page.wait_for_function('window.__pcgLabState && window.__pcgLabState.case_count===6',timeout=90000)
 def state():return page.evaluate('window.__pcgLabState')
 def record(action):records.append({'action':action,'state':state()});return records[-1]['state']
 def select(index):
  page.mouse.click(210,55);page.wait_for_timeout(90);page.mouse.click(200,90+26*index)
  page.wait_for_function('(i)=>window.__pcgLabState.selected===i && window.__pcgLabState.mode==="manual"',arg=index,timeout=10000)
  return record('mouse_select_'+str(index))
 def save():
  (OUT/'browser-final.json').write_text(json.dumps({'records':records,'events':events,'errors':errors},indent=2))
 try:
  initial=record('loaded');page.screenshot(path=str(OUT/'browser-initial.png'))
  page.keyboard.down('d');page.wait_for_timeout(160);page.keyboard.up('d');page.wait_for_timeout(70);moved=record('manual_D')
  assert moved['position'][0]>initial['position'][0]+10,'D did not move actual player'
  page.keyboard.down('a');page.wait_for_timeout(100);page.keyboard.up('a');page.wait_for_timeout(30);record('manual_A')
  page.keyboard.down('Space');page.wait_for_timeout(80);page.keyboard.up('Space');page.wait_for_timeout(100);jumped=record('manual_jump')
  assert jumped['events']['jump']>=1,'jump not accepted'
  x,y=jumped['position'];page.mouse.click(x+120,y+230);page.wait_for_timeout(120);shot=record('manual_shot_release')
  assert shot['events']['shot']>=1,'shot not accepted'
  page.mouse.click(535,55);page.wait_for_timeout(120);retry=record('mouse_retry')
  assert retry['mode']=='manual' and retry['events']['shot']==0,'retry did not reset case'
  select(3);page.mouse.move(323,348);page.keyboard.down('e');page.wait_for_timeout(70);page.keyboard.up('e');page.wait_for_timeout(700);hook=record('manual_E_hook')
  assert hook['events']['hook_cast']>=1,'hook cast not accepted'
  assert hook['events']['hook_contact']>=1,'hook did not contact real anchor'
  for index in range(6):
   select(index);page.mouse.click(690,55)
   page.wait_for_function('window.__pcgLabState.mode==="replay"',timeout=10000)
   page.wait_for_function('window.__pcgLabState.finished',timeout=20000)
   done=record('mouse_replay_'+str(index))
   assert done['safe'] and 'Exit reached' in done['status'] or (done['safe'] and 'exit reached' in done['status']),done
   if index==4:assert done['reward_visited'],'reward route did not visit reward region'
   page.screenshot(path=str(OUT/f'browser-replay-{index}.png'))
  record('all_checks_passed');save()
  print(json.dumps({'checks':'all passed','records':len(records),'errors':errors,'console_errors':[e for e in events if e['type']=='error']},indent=2))
 except Exception as e:
  records.append({'action':'failure','error':str(e),'state':state()});save();page.screenshot(path=str(OUT/'browser-failure.png'));raise
 finally:
  context.close();b.close()
