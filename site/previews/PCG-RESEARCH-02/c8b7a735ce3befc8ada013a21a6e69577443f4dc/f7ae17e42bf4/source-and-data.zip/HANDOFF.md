# PCG 研究交接

第二轮 PCG-RESEARCH-02 已在独立分支 `feature/composable-action-search` 实现能力合同、动作树推导、真实运动布置、状态反馈、成对噪声与有限捷径反例细化。最新说明 `COMPOSABLE-REPORT.md`，独立审查 `research/composable-review-v2.md`。

16 个固定移动+跳跃基底能力组合生成覆盖；六ID的64子集绑定矩阵36合法/28拒绝，不等于全部挑战生成覆盖。三轮1134提案→2000几何→1668稳定，173实际动作词不是173种趣味。最终20候选反馈轻389/400、中363/400，对照固定306/400、219/400；8/8反例细化保留见证。三个退化模块及双钩低容错明确warnings；17个无发现捷径不证明能力必要性。

`prototype/composable` 是新算法；旧代码与产物保留。新默认场景main_v2，旧场景可显式运行main.tscn。生成器支持显式能力列表，新能力需真实绑定/合同/几何/测试，不允许仅添加ID。追加move+wall关闭jump和jump+double关闭move都生成正例，no-move首次失败保留。

20真实输入展开回放、20本地Web回放、六段原生录像和20份Map Notes草图结构检查已过。Web新pack约65MiB；公开发布应共用第一轮字节相同的JS/WASM依赖，避免碰900MiB guard。正式游戏/编辑器未修改。趣味、正式消费者、Runtime、真人设备仍未验。

下面保留第一轮交接记录。

研究运行源 7c7b42e46e33c895d51741c1ca5d26a516568a27；游戏基线12f6cb0；公开build 8f8ded8ce59a。

https://zhipijun1996.github.io/gunman-rush-previews/previews/PCG-RESEARCH-01/7c7b42e46e33c895d51741c1ca5d26a516568a27/8f8ded8ce59a/

完成：论文/代码/许可审计，受限同域582-case对照，609-case交付评价，6试玩条目（5几何），21项实际Web GUI与公开6回放，真实20.7秒录像，6 Map Notes草图。

已保留：校准失败、CP域不公平V1、修订V2、最小导出缺动态依赖失败、真实工具失败。

下一步：同状态替代解规划、动作图层变异、鲁棒性目标、独立多run和真人试玩。当前不签高质量、Runtime在线生成、正式伤害/交易/存档或手机验收。

发布收据：delivery/PUBLICATION.json；论文/审计和原始数据在REPORT.md及研究包。正式游戏与Map Notes代码未修改；原型独立，编辑器仅单向草图导出。
